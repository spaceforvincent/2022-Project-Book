export default function Home() {
    return (
        <div className="button-group">
            <div>
                <svg><path
                    d="M427 201.9c-0.6-4.2-2.9-8-6.4-10.3L264.2 87.3c-4.9-3.3-11.4-3.3-16.3 0L91.4 191.6c-4 2.7-6.5 7.4-6.5 12.2v104.3c0 4.8 2.5 9.6 6.5 12.2l156.4 104.3c4.9 3.3 11.4 3.3 16.3 0L420.6 320.4c4-2.6 6.6-7.4 6.6-12.2V203.9C427.1 203.2 427.1 202.6 427 201.9 427 201.7 427.1 202.6 427 201.9zM270.7 127.1l115.2 76.8 -51.5 34.4 -63.8-42.7V127.1zM241.3 127.1v68.6l-63.8 42.7 -51.5-34.4L241.3 127.1zM114.3 231.4l36.8 24.6 -36.8 24.6V231.4zM241.3 384.9L126.1 308.1l51.5-34.4 63.8 42.6V384.9zM256 290.8l-52-34.8 52-34.8 52 34.8L256 290.8zM270.7 384.9V316.3l63.8-42.6 51.5 34.4L270.7 384.9zM397.7 280.6l-36.8-24.6 36.8-24.6V280.6z"/></svg>
            </div>
            <div>
                <svg><path
                    d="M427 201.9c-0.6-4.2-2.9-8-6.4-10.3L264.2 87.3c-4.9-3.3-11.4-3.3-16.3 0L91.4 191.6c-4 2.7-6.5 7.4-6.5 12.2v104.3c0 4.8 2.5 9.6 6.5 12.2l156.4 104.3c4.9 3.3 11.4 3.3 16.3 0L420.6 320.4c4-2.6 6.6-7.4 6.6-12.2V203.9C427.1 203.2 427.1 202.6 427 201.9 427 201.7 427.1 202.6 427 201.9zM270.7 127.1l115.2 76.8 -51.5 34.4 -63.8-42.7V127.1zM241.3 127.1v68.6l-63.8 42.7 -51.5-34.4L241.3 127.1zM114.3 231.4l36.8 24.6 -36.8 24.6V231.4zM241.3 384.9L126.1 308.1l51.5-34.4 63.8 42.6V384.9zM256 290.8l-52-34.8 52-34.8 52 34.8L256 290.8zM270.7 384.9V316.3l63.8-42.6 51.5 34.4L270.7 384.9zM397.7 280.6l-36.8-24.6 36.8-24.6V280.6z"/></svg>
            </div>
            <style jsx="jsx">
                {
                    ` .button-group {
                      position: relative;
                      z-index: 2;
                      display: flex;
                      min-width: 600px;
                      height: 100px;
                      background-color: #000;
                      border-radius: 7px;
                      padding: 4px;
                    }
                    .button-group > div {
                      cursor: pointer;
                      flex: 1;
                      background-image: linear-gradient(to top, #242424 0%, #303030 100%);
                      display: flex;
                      align-items: center;
                      justify-content: center;
                      margin: 1px;
                      transition: 0.2s;
                      font-size: 2.5em;
                      box-shadow: inset 0 20px 4px -21px rgba(255,255,255,0.4), 0 19px 13px 0 rgba(0,0,0,0.3);
                      color: #181818;
                      position: relative;
                      z-index: 2;
                    }
                    .button-group > div:before {
                      content: "";
                      display: block;
                      width: 0.8em;
                      height: 0.8em;
                      transition: 0.1s;
                      background-image: radial-gradient(circle 30px at center, #ebf7ff 0%, #b3e1ff 47%, #b3e1ff 100%);
                      position: absolute;
                      filter: blur(15px);
                      top: 50%;
                      left: 50%;
                      border-radius: 50%;
                      transform: translate(-50%, -50%);
                      opacity: 0;
                    }
                    .button-group > div:after {
                      content: "";
                      display: block;
                      height: 70px;
                      width: 1px;
                      position: absolute;
                      border-radius: 50%;
                      z-index: -1;
                      opacity: 0;
                      transition: 0.2s;
                      filter: blur(0px);
                      box-shadow: -75px 0 0px 0px rgba(179,225,255,0.3), 74px 0 0px 0px rgba(179,225,255,0.35);
                    }
                    .button-group > div svg {
                      height: 2em;
                      width: 2em;
                      position: relative;
                      display: block;
                      fill: #181818;
                      filter: drop-shadow(0 1px 1px rgba(255,255,255,0.15)) url("#inset-shadow");
                    }
                     `
                }</style>
        </div>

    );
}