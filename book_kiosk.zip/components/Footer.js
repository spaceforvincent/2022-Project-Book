import Link from "next/link"
import {useRouter} from "next/router"

export default function Footer() {
    const router = useRouter();
    return (
        <div>some where</div>
    );
}