-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7d211.p.ssafy.io    Database: data
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `board_id` int NOT NULL AUTO_INCREMENT,
  `id` varchar(30) NOT NULL,
  `title` varchar(30) NOT NULL,
  `story` varchar(300) NOT NULL,
  `type` varchar(20) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`board_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (6,'email5','title2','내용2','notice','2022-08-09'),(7,'email5','test','test','notice','2022-08-09'),(10,'test77','asdfa','sdf','notice','2022-08-11'),(11,'test77','asdfa','sdfadf','notice','2022-08-11'),(12,'test77','test','test','notice','2022-08-11'),(13,'test77','test','test','notice','2022-08-13'),(14,'test77','test11','test','notice','2022-08-13'),(15,'test77','test111','test111','notice','2022-08-13'),(16,'test77','test1234','test12345','notice','2022-08-13'),(17,'test77','test11','testtest','notice','2022-08-13'),(18,'test77','공지 작성 테스트','테스트 테스트','notice','2022-08-13'),(19,'sanggom@ssaty.com','상곰이 글쓴다!','곰곰곰','notice','2022-08-14'),(20,'sanggom@ssaty.com','소개 게시판 TEST','TEST','introduce','2022-08-16'),(21,'sanggom@ssaty.com','건의 게시판 TEST','TEST','suggestion','2022-08-16'),(23,'testing@test.com','test','test','FAQ','2022-08-18');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 10:53:28
